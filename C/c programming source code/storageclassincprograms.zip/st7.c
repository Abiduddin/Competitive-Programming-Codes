#include<stdio.h>
void f1();
int y;
main()
{
    extern int y; // extern variable can not be initialized.
    printf("y in main()=%d\n",y);
    f1();
    return 0;
}
int y; // y initialized to be zero.

void f1()
{
    y=y+1;
    printf("y in f1()=%d\n",y);
}

