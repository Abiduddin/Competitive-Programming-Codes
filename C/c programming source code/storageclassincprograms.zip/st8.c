#include<stdio.h>

int f1(int);
int a=3;
main()
{
    int count;
    for(count=1;count<=5;count++)
    {
        a=f1(count);
        printf("%d,",a);
    }
    return 0;
}

f1(int x)
{
    a+=x;// a=a+x;
    return a;
}

