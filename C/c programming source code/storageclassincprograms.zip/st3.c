#include<stdio.h>
void f();
int b;
main()
{
    //auto int a=5,i;
    int i;
    //printf("A=%d\n",a);
    printf("Before f() calling: b=%d\n",b);
    for(i=1;i<=3;i++)
      f();
    printf("After f() calling: b=%d\n",b);
    return 0;
}
 void f()
 {
     static int st;
     b=b+2;
     printf("Global b=%d\n",b);
     printf("st=%d\n",++st);

 }
