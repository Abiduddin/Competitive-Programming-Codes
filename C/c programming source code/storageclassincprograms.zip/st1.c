#include<stdio.h>
void f();
int b=7;
main()
{
    int a=5;
    printf("A=%d\n",a);
    printf("Before f() calling: b=%d\n",b);
    f();
    printf("After f() calling: b=%d\n",b);
    return 0;
}
 void f()
 {
     b=b+2;
 }
