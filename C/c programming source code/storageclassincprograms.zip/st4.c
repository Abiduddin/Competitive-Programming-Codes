#include<stdio.h>
void f1();
main()
{
    y=5;
    printf("y=%d\n",y);
    return 0;
}
int y;

void f1()
{
    y=y+1;
    printf("y in f1()=%d\n",y);
}

